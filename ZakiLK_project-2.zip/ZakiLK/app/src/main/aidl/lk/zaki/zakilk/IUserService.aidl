// lk/zaki/zakilk/IUserService.aidl
package lk.zaki.zakilk;

// الواجهة الرئيسية التي تربط التطبيقات الخارجية بخدمة ZAKI.. LK
// تعمل هذه الخدمة بصلاحيات ADB أو Root حسب طريقة التفعيل المختارة
interface IUserService {

    // تنفيذ أمر shell والحصول على النتيجة (يتطلب صلاحية ممنوحة مسبقًا)
    String execShellCommand(String command);

    // التحقق إذا كانت الخدمة تعمل حاليًا بصلاحية Root أو ADB فقط
    boolean isRunningAsRoot();

    // منح صلاحية لتطبيق معيّن عبر اسم الحزمة (package name)
    boolean grantPermission(String packageName, String permission);

    // سحب صلاحية من تطبيق معيّن
    boolean revokePermission(String packageName, String permission);

    // منح صلاحية Root لجميع التطبيقات المثبتة دفعة واحدة (يتطلب تأكيد المستخدم في الواجهة قبل الاستدعاء)
    boolean grantRootToAllApps();

    // الحصول على قائمة كل الصلاحيات الممنوحة حاليًا (لعرضها في سجل التدقيق)
    String getAuditLogJson();

    // إيقاف الخدمة بالكامل
    void destroy();
}
