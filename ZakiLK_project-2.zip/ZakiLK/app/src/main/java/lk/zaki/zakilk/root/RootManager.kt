package lk.zaki.zakilk.root

import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * مدير صلاحيات Root.
 * ملاحظة: هذا الكلاس يدير الصلاحيات على جهاز مروّت (Rooted) مسبقًا من قبل المستخدم.
 * هو لا يقوم بعمل Root للجهاز ولا يستغل أي ثغرة أمنية - فقط يوفر واجهة لإدارة
 * الصلاحيات الممنوحة لتطبيقات أخرى عبر su، بشكل مشابه لتطبيقات مثل Magisk Manager.
 */
object RootManager {

    fun isRoot(): Boolean {
        return try {
            val process = Runtime.getRuntime().exec("su -c id")
            process.waitFor() == 0
        } catch (e: Exception) {
            false
        }
    }

    fun runShellCommand(command: String): String {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val output = reader.readText()
            process.waitFor()
            output
        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }

    fun grantPermission(packageName: String, permission: String): Boolean {
        val result = runShellCommand("pm grant $packageName $permission")
        return !result.contains("Error", ignoreCase = true)
    }

    fun revokePermission(packageName: String, permission: String): Boolean {
        val result = runShellCommand("pm revoke $packageName $permission")
        return !result.contains("Error", ignoreCase = true)
    }

    /**
     * يجلب قائمة كل التطبيقات المثبتة (غير النظام) ويمنحها صلاحية Root
     * عن طريق إضافتها لقائمة السماح الخاصة بمدير الصلاحيات (su allowlist).
     * يجب استدعاؤها فقط بعد تأكيد صريح من المستخدم في الواجهة.
     */
    fun grantRootToAllInstalledApps(): Boolean {
        val listResult = runShellCommand("pm list packages -3")
        val packages = listResult.lines()
            .filter { it.startsWith("package:") }
            .map { it.removePrefix("package:").trim() }

        var allSucceeded = true
        for (pkg in packages) {
            // إضافة كل حزمة لقائمة السماح الخاصة بمدير su المستخدم بالجهاز
            val result = runShellCommand("su --add-allowlist $pkg")
            if (result.contains("Error", ignoreCase = true)) {
                allSucceeded = false
            }
        }
        return allSucceeded
    }
}
