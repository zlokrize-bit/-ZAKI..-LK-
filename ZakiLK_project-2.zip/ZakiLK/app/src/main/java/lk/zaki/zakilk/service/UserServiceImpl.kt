package lk.zaki.zakilk.service

import lk.zaki.zakilk.IUserService
import lk.zaki.zakilk.audit.AuditLogger
import lk.zaki.zakilk.root.RootManager

/**
 * التنفيذ الفعلي لخدمة IUserService.
 * هذه الخدمة تعمل في عملية منفصلة يتم تشغيلها عبر ADB (Wireless Debugging)
 * أو عبر Root، وتُستدعى من التطبيقات الأخرى عبر Binder/AIDL.
 */
class UserServiceImpl : IUserService.Stub() {

    override fun execShellCommand(command: String): String {
        val result = RootManager.runShellCommand(command)
        AuditLogger.log(action = "exec_shell", detail = command)
        return result
    }

    override fun isRunningAsRoot(): Boolean {
        return RootManager.isRoot()
    }

    override fun grantPermission(packageName: String, permission: String): Boolean {
        val success = RootManager.grantPermission(packageName, permission)
        AuditLogger.log(action = "grant_permission", detail = "$packageName -> $permission", success = success)
        return success
    }

    override fun revokePermission(packageName: String, permission: String): Boolean {
        val success = RootManager.revokePermission(packageName, permission)
        AuditLogger.log(action = "revoke_permission", detail = "$packageName -> $permission", success = success)
        return success
    }

    override fun grantRootToAllApps(): Boolean {
        // ملاحظة مهمة: هذه العملية حساسة أمنيًا.
        // يجب أن تُستدعى فقط بعد تأكيد صريح من المستخدم داخل واجهة التطبيق
        // (راجع RootManagerActivity - نافذة التحذير الإلزامية قبل الاستدعاء).
        val success = RootManager.grantRootToAllInstalledApps()
        AuditLogger.log(action = "grant_root_all_apps", detail = "bulk_operation", success = success)
        return success
    }

    override fun getAuditLogJson(): String {
        return AuditLogger.exportAsJson()
    }

    override fun destroy() {
        System.exit(0)
    }
}
