package lk.zaki.zakilk.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import lk.zaki.zakilk.R
import lk.zaki.zakilk.overlay.FloatingBubbleService

/**
 * الشاشة الرئيسية للتطبيق.
 * تعرض حالة الاتصال (ADB/Root)، وأزرار الوصول لكل الأقسام:
 * إدارة الصلاحيات، سجل التدقيق، القوالب، ومدير Root.
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // مثال: طلب صلاحية العرض فوق التطبيقات الأخرى (للبانل العائم)
        requestOverlayPermissionIfNeeded()
    }

    private fun requestOverlayPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }

    private fun startFloatingBubble() {
        val intent = Intent(this, FloatingBubbleService::class.java)
        startService(intent)
    }
}
