package lk.zaki.zakilk.audit

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * سجل التدقيق: يحتفظ بكل عملية صلاحية (منح/سحب/تنفيذ أمر) مع الوقت والنتيجة.
 * يُستخدم في شاشة "سجل التدقيق" بالتطبيق وفي التنبيهات الأمنية.
 */
data class AuditEntry(
    val timestamp: String,
    val action: String,
    val detail: String,
    val success: Boolean
)

object AuditLogger {

    private val entries = mutableListOf<AuditEntry>()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

    @Synchronized
    fun log(action: String, detail: String, success: Boolean = true) {
        entries.add(
            AuditEntry(
                timestamp = dateFormat.format(Date()),
                action = action,
                detail = detail,
                success = success
            )
        )
    }

    @Synchronized
    fun getAll(): List<AuditEntry> = entries.toList()

    @Synchronized
    fun exportAsJson(): String {
        val array = JSONArray()
        for (entry in entries) {
            val obj = JSONObject()
            obj.put("timestamp", entry.timestamp)
            obj.put("action", entry.action)
            obj.put("detail", entry.detail)
            obj.put("success", entry.success)
            array.put(obj)
        }
        return array.toString()
    }

    @Synchronized
    fun clear() {
        entries.clear()
    }
}
